package org.generation.elotitos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElotitosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElotitosApplication.class, args);
	}

}
